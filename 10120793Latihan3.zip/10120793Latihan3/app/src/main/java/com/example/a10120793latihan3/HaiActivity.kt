package com.example.a10120793latihan3

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class HaiActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_hai)
    }
}